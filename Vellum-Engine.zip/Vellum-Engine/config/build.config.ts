import { defineConfig } from 'vite';
import { BuildConfig } from '../client/src/lib/engine/build';

const defaultBuildConfig: BuildConfig = {
  platform: 'web',
  name: 'VellumGame',
  version: '1.0.0',
  assets: [],
  scenes: [],
  optimization: {
    minify: true,
    treeshake: true,
    compression: 'brotli'
  },
  webgl: {
    antialias: true,
    preserveDrawingBuffer: false,
    powerPreference: 'high-performance'
  },
  capabilities: {
    audio: true,
    webgl: true,
    webgl2: true,
    webassembly: true
  }
};

export const buildConfigs = {
  web: {
    ...defaultBuildConfig,
    platform: 'web' as const,
    outDir: 'dist/web',
  },
  desktop: {
    ...defaultBuildConfig,
    platform: 'desktop' as const,
    outDir: 'dist/desktop',
    electron: {
      main: {
        entry: 'electron/main.js',
        optimization: {
          minimize: true,
          nodeIntegration: true
        }
      },
      window: {
        width: 1280,
        height: 720,
        webPreferences: {
          contextIsolation: true,
          nodeIntegration: false,
          sandbox: true
        }
      }
    },
  },
  mobile: {
    ...defaultBuildConfig,
    platform: 'mobile' as const,
    outDir: 'dist/mobile',
    optimization: {
      minify: true,
      treeshake: true,
      compression: 'brotli'
    },
    webgl: {
      ...defaultBuildConfig.webgl,
      powerPreference: 'high-performance'
    },
    capacitor: {
      appId: 'com.vellum.game',
      appName: 'VellumGame',
      plugins: {
        splashscreen: {
          launchAutoHide: true,
          showSpinner: true
        }
      }
    },
  },
};

export default defineConfig({
  build: {
    target: 'esnext',
    outDir: 'dist',
    emptyOutDir: true,
    sourcemap: true,
    rollupOptions: {
      input: {
        main: './client/src/main.tsx',
      },
      output: {
        manualChunks: {
          vendor: ['react', 'react-dom', '@tanstack/react-query'],
          engine: [
            './client/src/lib/engine/scene.ts',
            './client/src/lib/engine/gameObject.ts',
            './client/src/lib/engine/components.ts',
            './client/src/lib/engine/physics.ts',
            './client/src/lib/engine/audio.ts',
            './client/src/lib/engine/resources.ts'
          ]
        }
      }
    },
    assetsInlineLimit: 4096,
    chunkSizeWarningLimit: 1000,
    cssCodeSplit: true,
    minify: 'esbuild',
    reportCompressedSize: true,
  },
  optimizeDeps: {
    include: ['react', 'react-dom', '@tanstack/react-query', 'matter-js', 'tone'],
    exclude: ['electron']
  }
});