import { User, Project, Scene, type InsertUser, type InsertProject, type InsertScene } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";
import { users, projects, scenes } from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Project operations
  getProjects(userId?: number): Promise<Project[]>;
  getProject(id: number): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  deleteProject(id: number): Promise<void>;

  // Scene operations
  getScenes(projectId: number): Promise<Scene[]>;
  getScene(id: number): Promise<Scene | undefined>;
  createScene(scene: InsertScene): Promise<Scene>;
  updateScene(id: number, scene: Partial<Scene>): Promise<Scene>;
  deleteScene(id: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }

  // Project operations
  async getProjects(userId?: number): Promise<Project[]> {
    if (userId) {
      return db.select().from(projects).where(eq(projects.userId, userId));
    }
    return db.select().from(projects);
  }

  async getProject(id: number): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project;
  }

  async createProject(project: InsertProject): Promise<Project> {
    const [newProject] = await db.insert(projects).values(project).returning();
    return newProject;
  }

  async deleteProject(id: number): Promise<void> {
    await db.delete(projects).where(eq(projects.id, id));
  }

  // Scene operations
  async getScenes(projectId: number): Promise<Scene[]> {
    return db.select().from(scenes).where(eq(scenes.projectId, projectId));
  }

  async getScene(id: number): Promise<Scene | undefined> {
    const [scene] = await db.select().from(scenes).where(eq(scenes.id, id));
    return scene;
  }

  async createScene(scene: InsertScene): Promise<Scene> {
    const [newScene] = await db.insert(scenes).values(scene).returning();
    return newScene;
  }

  async updateScene(id: number, updates: Partial<Scene>): Promise<Scene> {
    const [updatedScene] = await db
      .update(scenes)
      .set(updates)
      .where(eq(scenes.id, id))
      .returning();
    return updatedScene;
  }

  async deleteScene(id: number): Promise<void> {
    await db.delete(scenes).where(eq(scenes.id, id));
  }
}

export const storage = new DatabaseStorage();