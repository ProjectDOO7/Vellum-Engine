import type { Express, Request, Response, NextFunction } from "express";
import { createServer } from "http";
import { storage } from "./storage";
import { insertProjectSchema, insertSceneSchema, insertUserSchema } from "@shared/schema";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import bcrypt from "bcryptjs";
import session from "express-session";

declare module "express-session" {
  interface SessionData {
    userId: number;
  }
}

export function registerRoutes(app: Express) {
  const httpServer = createServer(app);

  // Session setup
  app.use(session({
    secret: process.env.SESSION_SECRET || "vellum-secret",
    resave: false,
    saveUninitialized: false,
    cookie: { secure: process.env.NODE_ENV === "production" }
  }));

  // Passport setup
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(new LocalStrategy(async (username, password, done) => {
    try {
      const user = await storage.getUserByUsername(username);
      if (!user) return done(null, false, { message: "Incorrect username" });

      const isValid = await bcrypt.compare(password, user.password);
      if (!isValid) return done(null, false, { message: "Incorrect password" });

      return done(null, user);
    } catch (err) {
      return done(err);
    }
  }));

  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (err) {
      done(err);
    }
  });

  // Auth middleware
  const requireAuth = (req: Request, res: Response, next: NextFunction) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    next();
  };

  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    const parsed = insertUserSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error });
    }

    const hashedPassword = await bcrypt.hash(parsed.data.password, 10);
    const user = await storage.createUser({
      ...parsed.data,
      password: hashedPassword,
    });

    req.login(user, (err) => {
      if (err) return res.status(500).json({ message: "Error logging in" });
      res.json({ message: "Registered successfully" });
    });
  });

  app.post("/api/auth/login", passport.authenticate("local"), (req, res) => {
    res.json({ message: "Logged in successfully" });
  });

  app.post("/api/auth/logout", (req, res) => {
    req.logout(() => {
      res.json({ message: "Logged out successfully" });
    });
  });

  // Project routes
  app.get("/api/projects", requireAuth, async (req: any, res) => {
    const projects = await storage.getProjects(req.user.id);
    res.json(projects);
  });

  app.post("/api/projects", requireAuth, async (req: any, res) => {
    const parsed = insertProjectSchema.safeParse({
      ...req.body,
      userId: req.user.id
    });
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error });
    }
    const project = await storage.createProject(parsed.data);
    res.json(project);
  });

  app.delete("/api/projects/:id", requireAuth, async (req: any, res) => {
    const project = await storage.getProject(Number(req.params.id));
    if (!project || project.userId !== req.user.id) {
      return res.status(403).json({ message: "Not authorized" });
    }
    await storage.deleteProject(Number(req.params.id));
    res.status(204).end();
  });

  // Scene routes
  app.get("/api/projects/:projectId/scenes", requireAuth, async (req: any, res) => {
    const project = await storage.getProject(Number(req.params.projectId));
    if (!project || project.userId !== req.user.id) {
      return res.status(403).json({ message: "Not authorized" });
    }
    const scenes = await storage.getScenes(Number(req.params.projectId));
    res.json(scenes);
  });

  app.post("/api/projects/:projectId/scenes", requireAuth, async (req: any, res) => {
    const project = await storage.getProject(Number(req.params.projectId));
    if (!project || project.userId !== req.user.id) {
      return res.status(403).json({ message: "Not authorized" });
    }

    const parsed = insertSceneSchema.safeParse({
      ...req.body,
      projectId: Number(req.params.projectId)
    });
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error });
    }
    const scene = await storage.createScene(parsed.data);
    res.json(scene);
  });

  app.put("/api/scenes/:id", requireAuth, async (req: any, res) => {
    const scene = await storage.getScene(Number(req.params.id));
    const project = scene && await storage.getProject(scene.projectId);
    if (!project || project.userId !== req.user.id) {
      return res.status(403).json({ message: "Not authorized" });
    }

    const updatedScene = await storage.updateScene(Number(req.params.id), req.body);
    res.json(updatedScene);
  });

  app.delete("/api/scenes/:id", requireAuth, async (req: any, res) => {
    const scene = await storage.getScene(Number(req.params.id));
    const project = scene && await storage.getProject(scene.projectId);
    if (!project || project.userId !== req.user.id) {
      return res.status(403).json({ message: "Not authorized" });
    }

    await storage.deleteScene(Number(req.params.id));
    res.status(204).end();
  });

  return httpServer;
}