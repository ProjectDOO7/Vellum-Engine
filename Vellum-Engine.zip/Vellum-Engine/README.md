# 🎮 Vellum Engine

O motor de jogos multiplataforma mais avançado, com suporte a física em tempo real, áudio espacial e gráficos de alta performance.

## ✨ Características

- 🌐 **Multiplataforma**: Desenvolva uma vez, publique em qualquer lugar (Web, Desktop, iOS e Android)
- ⚡ **Física Avançada**: Sistema de física robusto com Matter.js
- 🎵 **Áudio 3D**: Sistema de áudio espacial com Tone.js
- 🎨 **Editor Visual**: Interface intuitiva para criar cenas
- 🚀 **Alta Performance**: Otimizado com WebAssembly e WebGL
- 📦 **Assets**: Sistema completo de gerenciamento de recursos

## 🛠️ Tecnologias

- Frontend: React + TypeScript
- Backend: Node.js + Express
- Banco de Dados: PostgreSQL + Drizzle ORM
- Física: Matter.js
- Áudio: Tone.js
- Multiplataforma: Electron (Desktop) e Capacitor (Mobile)

## 📋 Pré-requisitos

- Node.js 20.x ou superior
- PostgreSQL 15.x ou superior
- Git

## 🚀 Como Iniciar

1. Clone o repositório:
```bash
git clone https://github.com/seu-usuario/vellum-engine.git
cd vellum-engine
```

2. Instale as dependências:
```bash
npm install
```

3. Configure as variáveis de ambiente:
Crie um arquivo `.env` na raiz do projeto:
```env
DATABASE_URL=postgresql://seu_usuario:sua_senha@localhost:5432/vellum
```

4. Inicie o servidor de desenvolvimento:
```bash
npm run dev
```

5. Acesse http://localhost:5000

## 📱 Build para Plataformas

### Web
```bash
npm run build:web
```

### Desktop (Electron)
```bash
npm run build:desktop
```

### Mobile (iOS/Android)
```bash
npm run build:mobile
```

## 🗂️ Estrutura do Projeto

```
vellum-engine/
├── client/               # Frontend React
│   ├── src/
│   │   ├── components/  # Componentes React
│   │   ├── lib/        # Biblioteca do motor
│   │   │   ├── engine/ # Core da engine
│   │   │   └── ...
│   │   └── pages/      # Páginas da aplicação
├── server/              # Backend Express
├── electron/            # Configuração Electron
├── config/             # Configurações
└── shared/             # Código compartilhado
```

## 🎯 Recursos Principais

### Motor de Física
- Detecção de colisão precisa
- Sistema de joints e constraints
- Simulação em tempo real
- Otimização para jogos 2D

### Sistema de Áudio
- Áudio posicional 3D
- Efeitos em tempo real
- Mixagem dinâmica
- Suporte a HRTF

### Editor Visual
- Interface drag-and-drop
- Preview em tempo real
- Gerenciamento de cenas
- Sistema de assets integrado

### Multiplataforma
- Build otimizado para web
- Suporte nativo desktop
- Apps iOS e Android
- Performance consistente

## 📚 Documentação

Para documentação completa, visite `/docs` no seu ambiente de desenvolvimento local.

## 🤝 Contribuindo

1. Fork o projeto
2. Crie uma branch (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add: nova funcionalidade'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

## 📝 Licença

Este projeto está sob a licença MIT. Veja o arquivo [LICENSE](LICENSE) para mais detalhes.

## 🚧 Status do Projeto

Em desenvolvimento ativo. Confira o [CHANGELOG](CHANGELOG.md) para ver as últimas atualizações.

## ✨ Agradecimentos

- Comunidade de desenvolvedores
- Contribuidores do projeto
- Bibliotecas open source utilizadas

---

Feito com ❤️ pela equipe Vellum Engine
