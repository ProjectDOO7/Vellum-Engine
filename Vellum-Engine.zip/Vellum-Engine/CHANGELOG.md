# Changelog

Todas as mudanças notáveis neste projeto serão documentadas neste arquivo.

O formato é baseado em [Keep a Changelog](https://keepachangelog.com/pt-BR/1.0.0/),
e este projeto adere ao [Versionamento Semântico](https://semver.org/lang/pt-BR/).

## [1.0.0] - 2025-02-05

### Adicionado
- Sistema de autenticação completo
- Editor visual com preview em tempo real
- Sistema de física baseado em Matter.js
- Sistema de áudio 3D com Tone.js
- Suporte multiplataforma (Web, Desktop, Mobile)
- Gerenciamento de assets
- Sistema de build otimizado
- Documentação inicial

### Recursos da Engine
- Motor de física avançado
- Sistema de áudio espacial
- Editor visual intuitivo
- Suporte a WebAssembly
- Sistema de plugins
- Marketplace integrado

### Melhorias Técnicas
- Otimização de performance
- Sistema de build configurável
- Suporte a múltiplos formatos de assets
- Interface responsiva e moderna

### Correções
- Otimização de memória no carregamento de assets
- Melhorias na detecção de colisão
- Ajustes no sistema de áudio

## [0.5.0] - 2025-01-15

### Adicionado
- Protótipo inicial do editor
- Implementação básica do motor de física
- Sistema de renderização 2D
- Estrutura base do projeto

### Melhorias
- Setup inicial do ambiente de desenvolvimento
- Configuração da pipeline de build
- Estruturação da documentação

## [0.1.0] - 2024-12-01

### Adicionado
- Estrutura inicial do projeto
- Configuração básica do ambiente
- Documentação preliminar
