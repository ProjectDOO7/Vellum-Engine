import { BuildManager } from '../client/src/lib/engine/build';
import { buildConfigs } from '../config/build.config';

interface BuildStats {
  platform: string;
  duration: number;
  success: boolean;
  outputSize: number;
  errors?: string[];
}

async function build() {
  const buildManager = BuildManager.getInstance();
  const platform = process.argv[2] || 'web';
  const startTime = Date.now();

  const config = buildConfigs[platform as keyof typeof buildConfigs];
  if (!config) {
    console.error(`Invalid platform: ${platform}`);
    process.exit(1);
  }

  console.log(`📦 Building for ${platform}...`);

  try {
    let result;
    switch (platform) {
      case 'web':
        console.log('🌐 Building for web platform...');
        result = await buildManager.buildForWeb(config);
        break;
      case 'desktop':
        console.log('🖥️  Building for desktop platforms (Windows, macOS, Linux)...');
        result = await buildManager.buildForDesktop(config);
        break;
      case 'mobile':
        console.log('📱 Building for mobile platforms (iOS, Android)...');
        result = await buildManager.buildForMobile(config);
        break;
      default:
        throw new Error(`Unsupported platform: ${platform}`);
    }

    const buildStats: BuildStats = {
      platform,
      duration: Date.now() - startTime,
      success: result.success,
      outputSize: result.stats?.bundleSize || 0,
      errors: result.errors
    };

    if (result.success) {
      console.log('\n✨ Build successful!');
      console.log(`📂 Output: ${result.outputPath}`);
      if (result.stats) {
        console.log('\n📊 Build Statistics:');
        console.log(`⚡ Bundle Size: ${formatBytes(result.stats.bundleSize)}`);
        console.log(`🖼️  Assets Size: ${formatBytes(result.stats.assetsSize)}`);
        console.log(`📦 Compression Ratio: ${result.stats.compressionRatio.toFixed(2)}x`);
      }
      console.log(`⏱️  Build Time: ${(buildStats.duration / 1000).toFixed(2)}s`);
    } else {
      console.error('\n❌ Build failed:', result.errors);
      process.exit(1);
    }
  } catch (error) {
    console.error('❌ Build failed:', error);
    process.exit(1);
  }
}

function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
}

build();