import { useEffect, useRef } from "react";
import { Scene } from "@/lib/engine/scene";

interface CanvasProps {
  scene: Scene;
}

export default function Canvas({ scene }: CanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Setup canvas size
    const updateSize = () => {
      const rect = canvas.parentElement?.getBoundingClientRect();
      if (!rect) return;

      // Set actual size to match display size
      canvas.width = rect.width;
      canvas.height = rect.height;

      // Set up coordinate system
      ctx.translate(0, 0);

      // Render the scene
      scene.render(ctx);
    };

    // Initial setup
    updateSize();

    // Handle resize
    const resizeObserver = new ResizeObserver(updateSize);
    if (canvas.parentElement) {
      resizeObserver.observe(canvas.parentElement);
    }

    // Set up render loop
    let animationFrameId: number;

    const render = () => {
      scene.render(ctx);
      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);

    // Cleanup
    return () => {
      resizeObserver.disconnect();
      cancelAnimationFrame(animationFrameId);
    };
  }, [scene]);

  return (
    <div className="w-full h-full bg-gray-100">
      <canvas
        ref={canvasRef}
        className="w-full h-full"
      />
    </div>
  );
}