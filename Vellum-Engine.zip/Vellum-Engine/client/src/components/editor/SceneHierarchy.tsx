import { Scene } from "@/lib/engine/scene";
import { GameObject } from "@/lib/engine/gameObject";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";

interface SceneHierarchyProps {
  scene: Scene;
  selectedObject: GameObject | null;
  onSelectObject: (object: GameObject) => void;
}

export default function SceneHierarchy({
  scene,
  selectedObject,
  onSelectObject
}: SceneHierarchyProps) {
  return (
    <div className="h-full flex flex-col">
      <div className="p-4 border-b">
        <h2 className="font-semibold">Scene Hierarchy</h2>
      </div>
      
      <ScrollArea className="flex-1">
        <div className="p-4">
          {scene.getObjects().map((object, index) => (
            <div
              key={index}
              className={cn(
                "px-2 py-1 rounded cursor-pointer hover:bg-accent",
                selectedObject === object && "bg-accent"
              )}
              onClick={() => onSelectObject(object)}
            >
              {object.name}
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}
