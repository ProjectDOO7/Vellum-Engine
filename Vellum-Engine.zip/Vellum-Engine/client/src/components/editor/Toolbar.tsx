import { Scene } from "@/lib/engine/scene";
import { GameObject } from "@/lib/engine/gameObject";
import { RectRenderer } from "@/lib/engine/components";
import { Button } from "@/components/ui/button";
import { Square, Image, Save, Play, Pause } from "lucide-react";

interface ToolbarProps {
  scene: Scene;
}

export default function Toolbar({ scene }: ToolbarProps) {
  const addRectangle = () => {
    const obj = new GameObject("Rectangle");
    obj.addComponent(new RectRenderer());
    scene.addObject(obj);
  };

  return (
    <div className="h-12 border-b flex items-center px-4 gap-2">
      <Button variant="ghost" size="icon" onClick={addRectangle}>
        <Square className="h-4 w-4" />
      </Button>
      
      <Button variant="ghost" size="icon" disabled>
        <Image className="h-4 w-4" />
      </Button>

      <div className="w-px h-6 bg-border mx-2" />

      <Button variant="ghost" size="icon">
        <Play className="h-4 w-4" />
      </Button>

      <Button variant="ghost" size="icon" disabled>
        <Pause className="h-4 w-4" />
      </Button>

      <div className="flex-1" />

      <Button>
        <Save className="h-4 w-4 mr-2" />
        Save Scene
      </Button>
    </div>
  );
}
