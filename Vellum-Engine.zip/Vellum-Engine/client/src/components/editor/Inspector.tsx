import { GameObject } from "@/lib/engine/gameObject";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";

interface InspectorProps {
  selectedObject: GameObject | null;
  onObjectChange: () => void;
}

export default function Inspector({ selectedObject, onObjectChange }: InspectorProps) {
  if (!selectedObject) {
    return (
      <div className="p-4">
        <p className="text-muted-foreground">No object selected</p>
      </div>
    );
  }

  const handleTransformChange = (key: string, value: number) => {
    if (key.includes('.')) {
      const [parent, child] = key.split('.');
      (selectedObject.transform as any)[parent][child] = value;
    } else {
      (selectedObject.transform as any)[key] = value;
    }
    onObjectChange();
  };

  return (
    <div className="p-4">
      <Card>
        <CardHeader>
          <CardTitle>Inspector</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="name">Name</Label>
            <Input
              id="name"
              value={selectedObject.name}
              onChange={(e) => {
                selectedObject.name = e.target.value;
                onObjectChange();
              }}
            />
          </div>

          <div className="space-y-2">
            <Label>Transform</Label>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label htmlFor="position-x">X</Label>
                <Input
                  id="position-x"
                  type="number"
                  value={selectedObject.transform.x}
                  onChange={(e) => handleTransformChange('x', +e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="position-y">Y</Label>
                <Input
                  id="position-y"
                  type="number"
                  value={selectedObject.transform.y}
                  onChange={(e) => handleTransformChange('y', +e.target.value)}
                />
              </div>
            </div>
            
            <div>
              <Label htmlFor="rotation">Rotation</Label>
              <Input
                id="rotation"
                type="number"
                value={selectedObject.transform.rotation}
                onChange={(e) => handleTransformChange('rotation', +e.target.value)}
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label htmlFor="scale-x">Scale X</Label>
                <Input
                  id="scale-x"
                  type="number"
                  value={selectedObject.transform.scale.x}
                  onChange={(e) => handleTransformChange('scale.x', +e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="scale-y">Scale Y</Label>
                <Input
                  id="scale-y"
                  type="number"
                  value={selectedObject.transform.scale.y}
                  onChange={(e) => handleTransformChange('scale.y', +e.target.value)}
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
