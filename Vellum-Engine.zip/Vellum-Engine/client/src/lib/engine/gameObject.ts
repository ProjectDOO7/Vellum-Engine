import { Component, SerializedComponent } from "./components";

export interface Transform {
  x: number;
  y: number;
  rotation: number;
  scale: { x: number; y: number };
}

export interface SerializedGameObject {
  name: string;
  transform: Transform;
  components: SerializedComponent[];
  children?: SerializedGameObject[];
  tags?: string[];
}

export class GameObject {
  name: string;
  transform: Transform;
  private components: Component[] = [];
  private children: GameObject[] = [];
  private parent: GameObject | null = null;
  private tags: Set<string> = new Set();

  constructor(name: string, transform: Transform = {
    x: 0,
    y: 0,
    rotation: 0,
    scale: { x: 1, y: 1 }
  }) {
    this.name = name;
    this.transform = transform;
  }

  addComponent(component: Component) {
    component.gameObject = this;
    this.components.push(component);
  }

  getComponent<T extends Component>(type: new (...args: any[]) => T): T | undefined {
    return this.components.find(c => c instanceof type) as T;
  }

  getComponents(): Component[] {
    return this.components;
  }

  addChild(child: GameObject) {
    child.parent = this;
    this.children.push(child);
  }

  removeChild(child: GameObject) {
    const index = this.children.indexOf(child);
    if (index > -1) {
      child.parent = null;
      this.children.splice(index, 1);
    }
  }

  getChildren(): GameObject[] {
    return this.children;
  }

  addTag(tag: string) {
    this.tags.add(tag);
  }

  removeTag(tag: string) {
    this.tags.delete(tag);
  }

  hasTag(tag: string): boolean {
    return this.tags.has(tag);
  }

  getTags(): string[] {
    return Array.from(this.tags);
  }

  getWorldTransform(): Transform {
    let worldTransform = { ...this.transform };

    if (this.parent) {
      const parentTransform = this.parent.getWorldTransform();
      worldTransform.x += parentTransform.x;
      worldTransform.y += parentTransform.y;
      worldTransform.rotation += parentTransform.rotation;
      worldTransform.scale.x *= parentTransform.scale.x;
      worldTransform.scale.y *= parentTransform.scale.y;
    }

    return worldTransform;
  }

  update(deltaTime: number) {
    // Update components
    this.components.forEach(component => {
      if (component.update) {
        component.update(deltaTime);
      }
    });

    // Update children
    this.children.forEach(child => {
      child.update(deltaTime);
    });
  }

  serialize(): SerializedGameObject {
    return {
      name: this.name,
      transform: this.transform,
      components: this.components.map(c => c.serialize()),
      children: this.children.map(c => c.serialize()),
      tags: Array.from(this.tags)
    };
  }

  static deserialize(data: SerializedGameObject): GameObject {
    const obj = new GameObject(data.name, data.transform);

    // Deserialize components
    data.components.forEach(compData => {
      const component = Component.deserialize(compData);
      if (component) obj.addComponent(component);
    });

    // Deserialize children
    if (data.children) {
      data.children.forEach(childData => {
        const child = GameObject.deserialize(childData);
        obj.addChild(child);
      });
    }

    // Restore tags
    if (data.tags) {
      data.tags.forEach(tag => obj.addTag(tag));
    }

    return obj;
  }

  render(ctx: CanvasRenderingContext2D) {
    ctx.save();

    // Apply world transform
    const worldTransform = this.getWorldTransform();
    ctx.translate(worldTransform.x, worldTransform.y);
    ctx.rotate(worldTransform.rotation);
    ctx.scale(worldTransform.scale.x, worldTransform.scale.y);

    // Render components
    this.components.forEach(component => {
      component.render(ctx);
    });

    // Render children
    this.children.forEach(child => {
      child.render(ctx);
    });

    ctx.restore();
  }

  destroy() {
    // Limpar componentes
    this.components.forEach(component => {
      if ('destroy' in component) {
        (component as any).destroy();
      }
    });
    this.components = [];

    // Destruir filhos recursivamente
    this.children.forEach(child => child.destroy());
    this.children = [];

    // Remover da hierarquia
    if (this.parent) {
      this.parent.removeChild(this);
    }
  }
}