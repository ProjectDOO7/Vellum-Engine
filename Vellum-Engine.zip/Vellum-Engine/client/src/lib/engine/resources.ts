type ResourceType = 'image' | 'audio' | 'sprite';

interface Resource {
  type: ResourceType;
  url: string;
  data: HTMLImageElement | HTMLAudioElement | ImageBitmap | ImageBitmap[];
  isLoaded: boolean;
  lastUsed: number;
}

export class ResourceManager {
  private static instance: ResourceManager;
  private resources: Map<string, Resource> = new Map();
  private loadingPromises: Map<string, Promise<void>> = new Map();

  private constructor() {}

  static getInstance(): ResourceManager {
    if (!ResourceManager.instance) {
      ResourceManager.instance = new ResourceManager();
    }
    return ResourceManager.instance;
  }

  async loadImage(url: string): Promise<HTMLImageElement> {
    const key = `image:${url}`;

    if (this.resources.has(key)) {
      const resource = this.resources.get(key)!;
      resource.lastUsed = Date.now();
      return resource.data as HTMLImageElement;
    }

    if (this.loadingPromises.has(key)) {
      await this.loadingPromises.get(key);
      return this.resources.get(key)!.data as HTMLImageElement;
    }

    const loadPromise = new Promise<void>((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        this.resources.set(key, {
          type: 'image',
          url,
          data: img,
          isLoaded: true,
          lastUsed: Date.now()
        });
        resolve();
      };
      img.onerror = reject;
      img.src = url;
    });

    this.loadingPromises.set(key, loadPromise);
    await loadPromise;
    this.loadingPromises.delete(key);

    return this.resources.get(key)!.data as HTMLImageElement;
  }

  async loadAudio(url: string): Promise<HTMLAudioElement> {
    const key = `audio:${url}`;

    if (this.resources.has(key)) {
      const resource = this.resources.get(key)!;
      resource.lastUsed = Date.now();
      return resource.data as HTMLAudioElement;
    }

    if (this.loadingPromises.has(key)) {
      await this.loadingPromises.get(key);
      return this.resources.get(key)!.data as HTMLAudioElement;
    }

    const loadPromise = new Promise<void>((resolve, reject) => {
      const audio = new Audio();
      audio.oncanplaythrough = () => {
        this.resources.set(key, {
          type: 'audio',
          url,
          data: audio,
          isLoaded: true,
          lastUsed: Date.now()
        });
        resolve();
      };
      audio.onerror = reject;
      audio.src = url;
    });

    this.loadingPromises.set(key, loadPromise);
    await loadPromise;
    this.loadingPromises.delete(key);

    return this.resources.get(key)!.data as HTMLAudioElement;
  }

  async loadSprite(url: string, frameWidth: number, frameHeight: number): Promise<ImageBitmap[]> {
    const key = `sprite:${url}`;

    if (this.resources.has(key)) {
      const resource = this.resources.get(key)!;
      resource.lastUsed = Date.now();
      return resource.data as ImageBitmap[];
    }

    const img = await this.loadImage(url);
    const frames: ImageBitmap[] = [];

    const numFramesX = Math.floor(img.width / frameWidth);
    const numFramesY = Math.floor(img.height / frameHeight);

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d')!;

    for (let y = 0; y < numFramesY; y++) {
      for (let x = 0; x < numFramesX; x++) {
        canvas.width = frameWidth;
        canvas.height = frameHeight;
        ctx.clearRect(0, 0, frameWidth, frameHeight);
        ctx.drawImage(
          img,
          x * frameWidth,
          y * frameHeight,
          frameWidth,
          frameHeight,
          0,
          0,
          frameWidth,
          frameHeight
        );
        const bitmap = await createImageBitmap(canvas);
        frames.push(bitmap);
      }
    }

    this.resources.set(key, {
      type: 'sprite',
      url,
      data: frames,
      isLoaded: true,
      lastUsed: Date.now()
    });

    return frames;
  }

  cleanupUnused(maxAge: number = 5 * 60 * 1000) { // 5 minutos por padrão
    const now = Date.now();
    Array.from(this.resources.entries()).forEach(([key, resource]) => {
      if (now - resource.lastUsed > maxAge) {
        this.resources.delete(key);
      }
    });
  }

  async preloadResources(resources: { type: ResourceType; url: string }[]) {
    const promises = resources.map(({ type, url }) => {
      switch (type) {
        case 'image':
          return this.loadImage(url);
        case 'audio':
          return this.loadAudio(url);
        default:
          return Promise.resolve();
      }
    });

    await Promise.all(promises);
  }
}