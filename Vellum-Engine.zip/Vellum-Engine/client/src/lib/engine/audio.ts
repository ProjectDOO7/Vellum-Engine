import * as Tone from 'tone';

export interface Sound {
  id: string;
  buffer: Tone.ToneAudioBuffer;
  player: Tone.Player;
}

export class AudioSystem {
  private static instance: AudioSystem;
  private sounds: Map<string, Sound> = new Map();
  private musicTracks: Map<string, Tone.Player> = new Map();
  private currentMusic?: string;

  private constructor() {
    Tone.start();
    Tone.Destination.volume.value = -6; // Volume inicial padrão
  }

  static getInstance(): AudioSystem {
    if (!AudioSystem.instance) {
      AudioSystem.instance = new AudioSystem();
    }
    return AudioSystem.instance;
  }

  async loadSound(id: string, url: string): Promise<void> {
    if (this.sounds.has(id)) return;

    try {
      const buffer = await Tone.Buffer.fromUrl(url);
      const player = new Tone.Player(buffer).toDestination();

      this.sounds.set(id, {
        id,
        buffer,
        player
      });
    } catch (error) {
      console.error(`Failed to load sound ${id}:`, error);
    }
  }

  async loadMusic(id: string, url: string): Promise<void> {
    if (this.musicTracks.has(id)) return;

    try {
      const player = new Tone.Player({
        url,
        loop: true,
        autostart: false
      }).toDestination();

      await Tone.loaded();
      this.musicTracks.set(id, player);
    } catch (error) {
      console.error(`Failed to load music ${id}:`, error);
    }
  }

  playSound(id: string, options: {
    volume?: number;
    playbackRate?: number;
    loop?: boolean;
  } = {}): void {
    const sound = this.sounds.get(id);
    if (!sound) {
      console.warn(`Sound ${id} not found`);
      return;
    }

    sound.player.stop();
    sound.player.volume.value = options.volume ?? 0;
    sound.player.playbackRate = options.playbackRate ?? 1;
    sound.player.loop = options.loop ?? false;
    sound.player.start();
  }

  stopSound(id: string): void {
    const sound = this.sounds.get(id);
    if (sound) {
      sound.player.stop();
    }
  }

  playMusic(id: string, options: { volume?: number; fadeIn?: number } = {}): void {
    if (this.currentMusic === id) return;

    const track = this.musicTracks.get(id);
    if (!track) {
      console.warn(`Music track ${id} not found`);
      return;
    }

    // Para a música atual se houver
    if (this.currentMusic) {
      const currentTrack = this.musicTracks.get(this.currentMusic);
      if (currentTrack) {
        currentTrack.stop();
      }
    }

    track.volume.value = options.volume ?? 0;
    if (options.fadeIn) {
      track.volume.value = -60;
      track.start();
      track.volume.rampTo(options.volume ?? 0, options.fadeIn);
    } else {
      track.start();
    }

    this.currentMusic = id;
  }

  stopMusic(fadeOut?: number): void {
    if (!this.currentMusic) return;

    const track = this.musicTracks.get(this.currentMusic);
    if (track) {
      if (fadeOut) {
        track.volume.rampTo(-60, fadeOut);
        setTimeout(() => track.stop(), fadeOut * 1000);
      } else {
        track.stop();
      }
    }
    this.currentMusic = undefined;
  }

  setMasterVolume(volume: number): void {
    Tone.Destination.volume.value = volume;
  }

  createReverb(options: {
    decay?: number;
    preDelay?: number;
    wet?: number;
  } = {}): Tone.Reverb {
    return new Tone.Reverb({
      decay: options.decay ?? 1.5,
      preDelay: options.preDelay ?? 0.01,
      wet: options.wet ?? 0.5
    }).toDestination();
  }

  createDelay(options: {
    delayTime?: number;
    feedback?: number;
    wet?: number;
  } = {}): Tone.FeedbackDelay {
    return new Tone.FeedbackDelay({
      delayTime: options.delayTime ?? 0.25,
      feedback: options.feedback ?? 0.5,
      wet: options.wet ?? 0.5
    }).toDestination();
  }

  dispose(): void {
    this.sounds.forEach(sound => {
      sound.player.dispose();
    });
    this.musicTracks.forEach(track => {
      track.dispose();
    });
    this.sounds.clear();
    this.musicTracks.clear();
    this.currentMusic = undefined;
  }
}