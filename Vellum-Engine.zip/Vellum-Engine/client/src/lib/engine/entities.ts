import { GameObject } from "./gameObject";
import { Component } from "./components";
import { ResourceManager } from "./resources";

export interface EntityConfig {
  name: string;
  type: string;
  tags?: string[];
  components?: Component[];
  children?: EntityConfig[];
}

export class EntityManager {
  private static instance: EntityManager;
  private entityTemplates: Map<string, EntityConfig> = new Map();
  private resourceManager: ResourceManager;

  private constructor() {
    this.resourceManager = ResourceManager.getInstance();
  }

  static getInstance(): EntityManager {
    if (!EntityManager.instance) {
      EntityManager.instance = new EntityManager();
    }
    return EntityManager.instance;
  }

  registerTemplate(type: string, config: EntityConfig) {
    this.entityTemplates.set(type, config);
  }

  createEntity(type: string, overrides: Partial<EntityConfig> = {}): GameObject {
    const template = this.entityTemplates.get(type);
    if (!template) {
      throw new Error(`No template found for entity type: ${type}`);
    }

    const config = { ...template, ...overrides };
    const entity = new GameObject(config.name);

    // Adicionar componentes
    if (config.components) {
      config.components.forEach(component => {
        entity.addComponent(component);
      });
    }

    // Adicionar tags
    if (config.tags) {
      config.tags.forEach(tag => {
        entity.addTag(tag);
      });
    }

    // Criar entidades filhas recursivamente
    if (config.children) {
      config.children.forEach(childConfig => {
        const child = this.createEntity(childConfig.type, childConfig);
        entity.addChild(child);
      });
    }

    return entity;
  }

  // Carregar uma cena inteira a partir de uma configuração
  async loadScene(sceneConfig: {
    entities: EntityConfig[];
    resources?: { type: 'image' | 'audio' | 'sprite'; url: string }[];
  }): Promise<GameObject[]> {
    // Pré-carregar recursos se necessário
    if (sceneConfig.resources) {
      await this.resourceManager.preloadResources(sceneConfig.resources);
    }

    // Criar todas as entidades da cena
    return sceneConfig.entities.map(config => 
      this.createEntity(config.type, config)
    );
  }
}

// Exemplos de templates predefinidos
export const CHARACTER_TEMPLATE: EntityConfig = {
  name: "Character",
  type: "character",
  tags: ["character", "movable"],
  components: [
    // Adicionar componentes específicos de personagem
  ]
};

export const PLATFORM_TEMPLATE: EntityConfig = {
  name: "Platform",
  type: "platform",
  tags: ["platform", "solid"],
  components: [
    // Adicionar componentes específicos de plataforma
  ]
};

export const COLLECTIBLE_TEMPLATE: EntityConfig = {
  name: "Collectible",
  type: "collectible",
  tags: ["collectible", "trigger"],
  components: [
    // Adicionar componentes específicos de coletável
  ]
};
