import { GameObject } from "./gameObject";
import { PhysicsComponent } from "./physics";

export interface SerializedComponent {
  type: string;
  [key: string]: any;
}

export abstract class Component {
  gameObject: GameObject | null = null;

  abstract serialize(): SerializedComponent;
  abstract render(ctx: CanvasRenderingContext2D): void;
  update?(deltaTime: number): void;

  static deserialize(data: SerializedComponent): Component | null {
    switch (data.type) {
      case "SpriteRenderer":
        return SpriteRenderer.fromData(data);
      case "RectRenderer":
        return RectRenderer.fromData(data);
      case "AnimationRenderer":
        return AnimationRenderer.fromData(data);
      case "Physics":
        return PhysicsRenderer.fromData(data);
      default:
        return null;
    }
  }
}

export class SpriteRenderer extends Component {
  private image: HTMLImageElement | null = null;

  constructor(public imageUrl: string) {
    super();
    this.loadImage();
  }

  private loadImage() {
    this.image = new Image();
    this.image.src = this.imageUrl;
  }

  serialize(): SerializedComponent {
    return {
      type: "SpriteRenderer",
      imageUrl: this.imageUrl
    };
  }

  static fromData(data: SerializedComponent): SpriteRenderer {
    return new SpriteRenderer(data.imageUrl);
  }

  render(ctx: CanvasRenderingContext2D) {
    if (this.image && this.image.complete) {
      ctx.drawImage(this.image, -this.image.width/2, -this.image.height/2);
    }
  }
}

export interface AnimationFrame {
  imageUrl: string;
  duration: number;
}

export class AnimationRenderer extends Component {
  private currentFrame = 0;
  private elapsed = 0;
  private images: HTMLImageElement[] = [];

  constructor(
    public frames: AnimationFrame[],
    public loop: boolean = true
  ) {
    super();
    this.loadImages();
  }

  private loadImages() {
    this.images = this.frames.map(frame => {
      const img = new Image();
      img.src = frame.imageUrl;
      return img;
    });
  }

  serialize(): SerializedComponent {
    return {
      type: "AnimationRenderer",
      frames: this.frames,
      loop: this.loop
    };
  }

  static fromData(data: SerializedComponent): AnimationRenderer {
    return new AnimationRenderer(data.frames, data.loop);
  }

  update(deltaTime: number) {
    this.elapsed += deltaTime;

    if (this.elapsed >= this.frames[this.currentFrame].duration) {
      this.elapsed = 0;
      this.currentFrame++;

      if (this.currentFrame >= this.frames.length) {
        if (this.loop) {
          this.currentFrame = 0;
        } else {
          this.currentFrame = this.frames.length - 1;
        }
      }
    }
  }

  render(ctx: CanvasRenderingContext2D) {
    const image = this.images[this.currentFrame];
    if (image && image.complete) {
      ctx.drawImage(image, -image.width/2, -image.height/2);
    }
  }
}

export class RectRenderer extends Component {
  constructor(
    public width: number = 100,
    public height: number = 100,
    public color: string = "#ff0000"
  ) {
    super();
  }

  serialize(): SerializedComponent {
    return {
      type: "RectRenderer",
      width: this.width,
      height: this.height,
      color: this.color
    };
  }

  static fromData(data: SerializedComponent): RectRenderer {
    return new RectRenderer(data.width, data.height, data.color);
  }

  render(ctx: CanvasRenderingContext2D) {
    ctx.fillStyle = this.color;
    ctx.fillRect(-this.width/2, -this.height/2, this.width, this.height);
  }
}

export class PhysicsRenderer extends Component {
  private physics: PhysicsComponent;

  constructor(body: { x: number; y: number; width: number; height: number; mass?: number }) {
    super();
    this.physics = new PhysicsComponent({
      bounds: {
        x: body.x,
        y: body.y,
        width: body.width,
        height: body.height
      },
      velocity: { x: 0, y: 0 },
      acceleration: { x: 0, y: 0 },
      mass: body.mass || 1
    });
  }

  serialize(): SerializedComponent {
    const bounds = this.physics.getBounds();
    return {
      type: "Physics",
      x: bounds.x,
      y: bounds.y,
      width: bounds.width,
      height: bounds.height
    };
  }

  static fromData(data: SerializedComponent): PhysicsRenderer {
    return new PhysicsRenderer(data);
  }

  getPhysics(): PhysicsComponent {
    return this.physics;
  }

  update(deltaTime: number) {
    this.physics.update(deltaTime);
    if (this.gameObject) {
      const pos = this.physics.getPosition();
      this.gameObject.transform.x = pos.x;
      this.gameObject.transform.y = pos.y;
    }
  }

  render(ctx: CanvasRenderingContext2D) {
    // Optional: render physics debug information
    if (process.env.NODE_ENV === 'development') {
      const bounds = this.physics.getBounds();
      ctx.strokeStyle = '#00ff00';
      ctx.strokeRect(
        -bounds.width/2,
        -bounds.height/2,
        bounds.width,
        bounds.height
      );
    }
  }
}