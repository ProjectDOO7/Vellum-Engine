import { Scene } from "./scene";
import { GameObject } from "./gameObject";
import { ResourceManager } from "./resources";

export interface BuildConfig {
  platform: 'web' | 'desktop' | 'mobile';
  name: string;
  version: string;
  assets: {
    url: string;
    type: 'image' | 'audio' | 'sprite' | 'model';
    options?: {
      compress?: boolean;
      quality?: number;
      format?: string;
    };
  }[];
  scenes: Scene[];
  entryScene?: string;
  optimization?: {
    minify: boolean;
    treeshake: boolean;
    compression: 'none' | 'gzip' | 'brotli';
  };
  webgl?: {
    antialias: boolean;
    preserveDrawingBuffer: boolean;
    powerPreference: 'default' | 'high-performance' | 'low-power';
  };
  capabilities?: {
    audio: boolean;
    webgl: boolean;
    webgl2: boolean;
    webassembly: boolean;
  };
}

export interface BuildResult {
  success: boolean;
  outputPath: string;
  errors?: string[];
  stats?: {
    bundleSize: number;
    assetsSize: number;
    compressionRatio: number;
  };
}

export class BuildManager {
  private static instance: BuildManager;
  private resourceManager: ResourceManager;

  private constructor() {
    this.resourceManager = ResourceManager.getInstance();
  }

  static getInstance(): BuildManager {
    if (!BuildManager.instance) {
      BuildManager.instance = new BuildManager();
    }
    return BuildManager.instance;
  }

  private async optimizeAssets(assets: BuildConfig['assets'], platform: BuildConfig['platform']) {
    const optimizedAssets = await Promise.all(
      assets.map(async (asset) => {
        const optimized = { ...asset };

        if (platform === 'mobile') {
          // Otimizações específicas para mobile
          optimized.options = {
            ...optimized.options,
            compress: true,
            quality: asset.type === 'image' ? 0.8 : undefined,
            format: asset.type === 'image' ? 'webp' : undefined
          };
        }

        return optimized;
      })
    );

    return optimizedAssets;
  }

  async buildForWeb(config: BuildConfig): Promise<BuildResult> {
    try {
      // Otimizar assets para web
      const optimizedAssets = await this.optimizeAssets(config.assets, 'web');

      // Carregar e processar todos os recursos
      await this.resourceManager.preloadResources(
        optimizedAssets.map(asset => ({
          type: asset.type as 'image' | 'audio' | 'sprite',
          url: asset.url
        }))
      );

      // Serializar todas as cenas com otimizações
      const scenes = config.scenes.map(scene => ({
        ...scene.serialize(),
        assets: optimizedAssets
      }));

      // Criar o bundle para web com suporte a WebAssembly
      const bundle = {
        name: config.name,
        version: config.version,
        scenes,
        entryScene: config.entryScene || scenes[0].name,
        capabilities: {
          ...config.capabilities,
          webassembly: true
        }
      };

      return {
        success: true,
        outputPath: '/dist/web',
        stats: {
          bundleSize: 0, // Será calculado durante o build
          assetsSize: 0,
          compressionRatio: 0
        }
      };
    } catch (error) {
      return {
        success: false,
        outputPath: '',
        errors: [error instanceof Error ? error.message : 'Unknown error during build']
      };
    }
  }

  async buildForDesktop(config: BuildConfig): Promise<BuildResult> {
    try {
      // Build web primeiro como base
      const webBuild = await this.buildForWeb({
        ...config,
        optimization: {
          ...config.optimization,
          compression: 'none' // Não precisamos de compressão para desktop
        }
      });

      if (!webBuild.success) {
        throw new Error('Web build failed');
      }

      // Configuração do Electron com otimizações
      const electronConfig = {
        main: {
          entry: 'electron/main.js',
          target: 'electron-main',
          optimization: {
            minimize: true,
            nodeIntegration: true
          }
        },
        preload: {
          entry: 'electron/preload.js',
          target: 'electron-preload',
          sandbox: true
        },
        window: {
          width: 1280,
          height: 720,
          webPreferences: {
            contextIsolation: true,
            nodeIntegration: false
          }
        }
      };

      return {
        success: true,
        outputPath: '/dist/desktop',
        stats: webBuild.stats
      };
    } catch (error) {
      return {
        success: false,
        outputPath: '',
        errors: [error instanceof Error ? error.message : 'Unknown error during desktop build']
      };
    }
  }

  async buildForMobile(config: BuildConfig): Promise<BuildResult> {
    try {
      // Build web otimizado para mobile
      const webBuild = await this.buildForWeb({
        ...config,
        optimization: {
          minify: true,
          treeshake: true,
          compression: 'brotli'
        },
        webgl: {
          ...config.webgl,
          powerPreference: 'high-performance'
        }
      });

      if (!webBuild.success) {
        throw new Error('Web build failed');
      }

      // Configuração do Capacitor com otimizações
      const capacitorConfig = {
        appId: `com.vellum.${config.name.toLowerCase()}`,
        appName: config.name,
        webDir: 'dist/web',
        server: {
          androidScheme: 'https',
          cleartext: false,
          hostname: 'localhost'
        },
        plugins: {
          splashscreen: {
            launchAutoHide: true,
            backgroundColor: "#ffffffff",
            androidScaleType: "CENTER_CROP",
            showSpinner: true,
            splashFullScreen: true,
            splashImmersive: true
          }
        },
        cordova: {}
      };

      return {
        success: true,
        outputPath: '/dist/mobile',
        stats: webBuild.stats
      };
    } catch (error) {
      return {
        success: false,
        outputPath: '',
        errors: [error instanceof Error ? error.message : 'Unknown error during mobile build']
      };
    }
  }

  private getAssetType(asset: string): 'image' | 'audio' | 'sprite' {
    const extension = asset.split('.').pop()?.toLowerCase();
    switch (extension) {
      case 'png':
      case 'jpg':
      case 'jpeg':
      case 'gif':
      case 'webp':
        return 'image';
      case 'mp3':
      case 'wav':
      case 'ogg':
        return 'audio';
      case 'json': // Para spritesheets
        return 'sprite';
      default:
        return 'image';
    }
  }
}