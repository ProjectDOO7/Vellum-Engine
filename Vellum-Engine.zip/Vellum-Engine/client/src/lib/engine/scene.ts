import { GameObject, SerializedGameObject } from "./gameObject";
import { PhysicsSystem } from "./physics";
import { EntityManager } from "./entities";
import { ResourceManager } from "./resources";

export interface SerializedScene {
  objects: SerializedGameObject[];
  resources?: { type: 'image' | 'audio' | 'sprite'; url: string }[];
}

export class Scene {
  private objects: GameObject[] = [];
  private physicsSystem: PhysicsSystem;
  private lastUpdate: number = 0;
  private entityManager: EntityManager;
  private resourceManager: ResourceManager;

  constructor() {
    this.physicsSystem = new PhysicsSystem();
    this.entityManager = EntityManager.getInstance();
    this.resourceManager = ResourceManager.getInstance();
  }

  async loadResources(resources: { type: 'image' | 'audio' | 'sprite'; url: string }[]) {
    await this.resourceManager.preloadResources(resources);
  }

  addObject(object: GameObject) {
    this.objects.push(object);
    // If object has physics component, add it to physics system
    const physics = object.getComponents().find(c => c.constructor.name === 'PhysicsRenderer');
    if (physics && 'getPhysics' in physics) {
      this.physicsSystem.addBody((physics as any).getPhysics());
    }
  }

  removeObject(object: GameObject) {
    const index = this.objects.indexOf(object);
    if (index > -1) {
      const physics = object.getComponents().find(c => c.constructor.name === 'PhysicsRenderer');
      if (physics && 'getPhysics' in physics) {
        this.physicsSystem.removeBody((physics as any).getPhysics());
      }
      this.objects.splice(index, 1);
      object.destroy();
    }
  }

  getObjects(): GameObject[] {
    return this.objects;
  }

  findObjectsByTag(tag: string): GameObject[] {
    return this.objects.filter(obj => obj.hasTag(tag));
  }

  findObjectByName(name: string): GameObject | undefined {
    return this.objects.find(obj => obj.name === name);
  }

  async createEntity(type: string, config: any = {}) {
    const entity = this.entityManager.createEntity(type, config);
    this.addObject(entity);
    return entity;
  }

  serialize(): SerializedScene {
    return {
      objects: this.objects.map(obj => obj.serialize())
    };
  }

  static async deserialize(data: SerializedScene): Promise<Scene> {
    const scene = new Scene();

    // Carregar recursos primeiro, se houver
    if (data.resources) {
      await scene.loadResources(data.resources);
    }

    // Depois criar os objetos
    data.objects.forEach(objData => {
      scene.addObject(GameObject.deserialize(objData));
    });

    return scene;
  }

  update(timestamp: number) {
    // Calculate delta time in seconds
    const deltaTime = (timestamp - this.lastUpdate) / 1000;
    this.lastUpdate = timestamp;

    // Update physics system
    this.physicsSystem.update(deltaTime);

    // Update all game objects and their components
    this.objects.forEach(obj => {
      obj.update(deltaTime);
    });

    // Limpar recursos não utilizados periodicamente
    if (Math.random() < 0.01) { // 1% de chance por frame
      this.resourceManager.cleanupUnused();
    }
  }

  render(ctx: CanvasRenderingContext2D) {
    // Clear the canvas
    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);

    // Render all objects
    this.objects.forEach(obj => obj.render(ctx));
  }

  setGravity(gravity: { x: number; y: number }) {
    this.physicsSystem.setGravity(gravity);
  }

  clear() {
    // Destruir todos os objetos
    this.objects.forEach(obj => obj.destroy());
    this.objects = [];
  }
}