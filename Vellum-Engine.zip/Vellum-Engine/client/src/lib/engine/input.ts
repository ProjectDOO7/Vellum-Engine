import { useState, useEffect } from 'react';

export interface InputState {
  keys: Set<string>;
  mousePosition: { x: number; y: number };
  mouseButtons: Set<number>;
}

export function useInput() {
  const [inputState, setInputState] = useState<InputState>({
    keys: new Set(),
    mousePosition: { x: 0, y: 0 },
    mouseButtons: new Set()
  });

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      setInputState(prev => ({
        ...prev,
        keys: new Set([...prev.keys, e.key.toLowerCase()])
      }));
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      setInputState(prev => {
        const newKeys = new Set(prev.keys);
        newKeys.delete(e.key.toLowerCase());
        return { ...prev, keys: newKeys };
      });
    };

    const handleMouseMove = (e: MouseEvent) => {
      setInputState(prev => ({
        ...prev,
        mousePosition: { x: e.clientX, y: e.clientY }
      }));
    };

    const handleMouseDown = (e: MouseEvent) => {
      setInputState(prev => ({
        ...prev,
        mouseButtons: new Set([...prev.mouseButtons, e.button])
      }));
    };

    const handleMouseUp = (e: MouseEvent) => {
      setInputState(prev => {
        const newButtons = new Set(prev.mouseButtons);
        newButtons.delete(e.button);
        return { ...prev, mouseButtons: newButtons };
      });
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, []);

  return inputState;
}
