import Matter from 'matter-js';
import { Common } from 'matter-js';

export interface Bounds {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface PhysicsBody {
  velocity: { x: number; y: number };
  acceleration: { x: number; y: number };
  mass: number;
  bounds: Bounds;
}

export interface PhysicsConfig {
  gravity?: { x: number; y: number; scale?: number };
  enableSleeping?: boolean;
  velocityIterations?: number;
  positionIterations?: number;
  broadphase?: 'bruteForce' | 'grid';
  constraintIterations?: number;
}

// Reimplementação do PhysicsComponent
export class PhysicsComponent {
  private body: PhysicsBody;

  constructor(body: PhysicsBody) {
    this.body = body;
  }

  update(deltaTime: number): void {
    // Atualiza velocidade baseado na aceleração
    this.body.velocity.x += this.body.acceleration.x * deltaTime;
    this.body.velocity.y += this.body.acceleration.y * deltaTime;

    // Atualiza posição baseado na velocidade
    this.body.bounds.x += this.body.velocity.x * deltaTime;
    this.body.bounds.y += this.body.velocity.y * deltaTime;
  }

  applyForce(force: { x: number; y: number }): void {
    this.body.acceleration.x += force.x / this.body.mass;
    this.body.acceleration.y += force.y / this.body.mass;
  }

  setVelocity(velocity: { x: number; y: number }): void {
    this.body.velocity = velocity;
  }

  getPosition(): { x: number; y: number } {
    return {
      x: this.body.bounds.x,
      y: this.body.bounds.y
    };
  }

  getBounds(): Bounds {
    return this.body.bounds;
  }
}

export class PhysicsSystem {
  private engine: Matter.Engine;
  private world: Matter.World;
  private bodies: Map<number, Matter.Body> = new Map();
  private nextBodyId: number = 1;
  private debugMode: boolean = false;
  private perfStats: {
    lastUpdateTime: number;
    frameTime: number[];
    bodyCount: number[];
  } = {
    lastUpdateTime: 0,
    frameTime: [],
    bodyCount: []
  };

  constructor(config: PhysicsConfig = {}) {
    this.engine = Matter.Engine.create({
      enableSleeping: config.enableSleeping ?? true,
      constraintIterations: config.constraintIterations ?? 4,
      positionIterations: config.positionIterations ?? 6,
      velocityIterations: config.velocityIterations ?? 4,
    });

    this.world = this.engine.world;

    // Configurar gravidade
    this.world.gravity = {
      x: config.gravity?.x ?? 0,
      y: config.gravity?.y ?? 9.81,
      scale: config.gravity?.scale ?? 0.001
    };

    // Otimizações de performance
    if (typeof window !== 'undefined') {
      Matter.Common.setDecomp(require('poly-decomp'));
    }
  }

  enableDebug(enabled: boolean = true): void {
    this.debugMode = enabled;
  }

  update(deltaTime: number): void {
    const startTime = performance.now();

    // Limitar deltaTime para evitar problemas com FPS muito baixo
    const cappedDelta = Math.min(deltaTime, 1000 / 30);

    // Atualizar física com interpolação suave
    Matter.Engine.update(this.engine, cappedDelta);

    // Limpeza automática de corpos inativos
    if (this.engine.enableSleeping) {
      Array.from(this.bodies.entries()).forEach(([id, body]) => {
        if (body.isSleeping) {
          this.removeBody(id);
        }
      });
    }

    // Coletar métricas de performance em modo debug
    if (this.debugMode) {
      const endTime = performance.now();
      const frameTime = endTime - startTime;

      this.perfStats.frameTime.push(frameTime);
      this.perfStats.bodyCount.push(this.bodies.size);

      if (this.perfStats.frameTime.length > 60) {
        this.perfStats.frameTime.shift();
        this.perfStats.bodyCount.shift();
      }
    }
  }

  addBody(body: Matter.Body): number {
    try {
      // Otimizações de performance para o corpo
      Matter.Body.setInertia(body, body.inertia);

      Matter.World.add(this.world, body);
      const id = this.nextBodyId++;
      this.bodies.set(id, body);
      return id;
    } catch (error) {
      console.error("Erro ao adicionar corpo:", error);
      throw error;
    }
  }

  removeBody(id: number): boolean {
    const body = this.bodies.get(id);
    if (!body) return false;

    try {
      Matter.World.remove(this.world, body);
      this.bodies.delete(id);
      return true;
    } catch (error) {
      console.error("Erro ao remover corpo:", error);
      return false;
    }
  }

  createRectangle(options: {
    x: number;
    y: number;
    width: number;
    height: number;
    isStatic?: boolean;
    mass?: number;
    friction?: number;
    restitution?: number;
    angle?: number;
    chamfer?: number;
  }): number {
    try {
      const body = Matter.Bodies.rectangle(
        options.x,
        options.y,
        options.width,
        options.height,
        {
          isStatic: options.isStatic,
          mass: options.mass,
          friction: options.friction ?? 0.1,
          restitution: options.restitution ?? 0.6,
          angle: options.angle ?? 0,
          chamfer: options.chamfer ? { radius: options.chamfer } : undefined,
          render: { visible: true }
        }
      );

      return this.addBody(body);
    } catch (error) {
      console.error("Erro ao criar retângulo:", error);
      throw error;
    }
  }

  setGravity(gravity: { x: number; y: number; scale?: number }): void {
    this.world.gravity = {
      x: gravity.x,
      y: gravity.y,
      scale: gravity.scale ?? this.world.gravity.scale
    };
  }

  getPerformanceMetrics() {
    if (!this.debugMode) return null;

    const avgFrameTime = this.perfStats.frameTime.reduce((a, b) => a + b, 0) / this.perfStats.frameTime.length;
    const avgBodyCount = this.perfStats.bodyCount.reduce((a, b) => a + b, 0) / this.perfStats.bodyCount.length;

    return {
      averageFrameTime: avgFrameTime.toFixed(2),
      averageBodyCount: Math.round(avgBodyCount),
      activeBodyCount: this.bodies.size,
      sleepingBodies: Array.from(this.bodies.values()).filter(b => b.isSleeping).length,
      constraintIterations: this.engine.constraintIterations,
      timeScale: this.engine.timing.timeScale
    };
  }

  dispose(): void {
    try {
      Matter.World.clear(this.world, false);
      Matter.Engine.clear(this.engine);
      this.bodies.clear();
      this.perfStats = {
        lastUpdateTime: 0,
        frameTime: [],
        bodyCount: []
      };
    } catch (error) {
      console.error("Erro ao limpar sistema de física:", error);
    }
  }
}