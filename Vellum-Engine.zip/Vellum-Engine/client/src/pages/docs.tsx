import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export default function Docs() {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-8">Documentação do Vellum Engine</h1>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <Card className="p-6">
            <h2 className="text-2xl font-semibold mb-4">🚀 Começando</h2>
            <div className="space-y-2 text-muted-foreground mb-4">
              <p>Aprenda os fundamentos do Vellum Engine:</p>
              <ul className="list-disc list-inside">
                <li>Como configurar seu ambiente de desenvolvimento</li>
                <li>Estrutura básica de um projeto</li>
                <li>Criação da primeira cena interativa</li>
              </ul>
            </div>
            <Link href="/docs/getting-started">
              <Button className="mt-4" variant="outline">Ler mais</Button>
            </Link>
          </Card>

          <Card className="p-6">
            <h2 className="text-2xl font-semibold mb-4">🎮 Motor de Física</h2>
            <div className="space-y-2 text-muted-foreground mb-4">
              <p>Sistema de física avançado para jogos 2D:</p>
              <ul className="list-disc list-inside">
                <li>Detecção de colisão precisa</li>
                <li>Simulação de gravidade e forças</li>
                <li>Joints para conexões entre objetos</li>
              </ul>
            </div>
            <Link href="/docs/physics">
              <Button className="mt-4" variant="outline">Ler mais</Button>
            </Link>
          </Card>

          <Card className="p-6">
            <h2 className="text-2xl font-semibold mb-4">🎨 Renderização</h2>
            <div className="space-y-2 text-muted-foreground mb-4">
              <p>Sistema de renderização otimizado:</p>
              <ul className="list-disc list-inside">
                <li>Sistema de sprites com animações</li>
                <li>Efeitos visuais e partículas</li>
                <li>Otimizações de performance</li>
              </ul>
            </div>
            <Link href="/docs/rendering">
              <Button className="mt-4" variant="outline">Ler mais</Button>
            </Link>
          </Card>

          <Card className="p-6">
            <h2 className="text-2xl font-semibold mb-4">🎵 Sistema de Áudio</h2>
            <div className="space-y-2 text-muted-foreground mb-4">
              <p>Sistema de áudio espacial completo:</p>
              <ul className="list-disc list-inside">
                <li>Áudio posicional 3D</li>
                <li>Mixagem dinâmica de sons</li>
                <li>Efeitos de áudio em tempo real</li>
              </ul>
            </div>
            <Link href="/docs/audio">
              <Button className="mt-4" variant="outline">Ler mais</Button>
            </Link>
          </Card>

          <Card className="p-6">
            <h2 className="text-2xl font-semibold mb-4">📱 Multiplataforma</h2>
            <div className="space-y-2 text-muted-foreground mb-4">
              <p>Suporte multiplataforma nativo:</p>
              <ul className="list-disc list-inside">
                <li>Compilação otimizada para Web</li>
                <li>Builds para Windows, macOS e Linux</li>
                <li>Apps nativos para iOS e Android</li>
              </ul>
            </div>
            <Link href="/docs/platforms">
              <Button className="mt-4" variant="outline">Ler mais</Button>
            </Link>
          </Card>

          <Card className="p-6">
            <h2 className="text-2xl font-semibold mb-4">🛠️ Plugins</h2>
            <div className="space-y-2 text-muted-foreground mb-4">
              <p>Sistema extensível de plugins:</p>
              <ul className="list-disc list-inside">
                <li>API para desenvolvimento de plugins</li>
                <li>Marketplace integrado</li>
                <li>Exemplos e templates</li>
              </ul>
            </div>
            <Link href="/docs/plugins">
              <Button className="mt-4" variant="outline">Ler mais</Button>
            </Link>
          </Card>
        </div>
      </div>
    </div>
  );
}