import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { SiUnrealengine, SiUnity, SiGodotengine } from "react-icons/si";
import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef, useState, useEffect } from "react";
import { Loader2, MessageCircle, Mail, Github, Twitter, Send } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";

interface FeatureCardProps {
  title: string;
  description: string;
  icon?: React.ComponentType<{ className?: string }>;
  delay?: number;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ 
  title, 
  description, 
  icon: Icon, 
  delay = 0 
}) => {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 50 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
      transition={{ duration: 0.5, delay }}
    >
      <Card className="p-6 hover:shadow-lg transition-all hover:scale-105 cursor-pointer border-primary/20">
        <div className="flex items-start space-x-4">
          <div className="mt-1">
            {Icon && <Icon className="h-8 w-8 text-primary" />}
          </div>
          <div>
            <h3 className="text-2xl font-semibold mb-2">{title}</h3>
            <p className="text-muted-foreground">{description}</p>
          </div>
        </div>
      </Card>
    </motion.div>
  );
};

const DemoSection = () => {
  const [isLoading, setIsLoading] = useState(true);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!canvasRef.current) return;
    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;

    // Demo animation setup
    let frame = 0;
    const balls: { x: number; y: number; vx: number; vy: number; radius: number }[] = [];

    for (let i = 0; i < 5; i++) {
      balls.push({
        x: Math.random() * canvasRef.current.width,
        y: Math.random() * canvasRef.current.height,
        vx: (Math.random() - 0.5) * 4,
        vy: (Math.random() - 0.5) * 4,
        radius: 10 + Math.random() * 20
      });
    }

    setIsLoading(false);

    const animate = () => {
      if (!canvasRef.current || !ctx) return;

      ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);

      // Update and draw balls
      balls.forEach(ball => {
        ball.x += ball.vx;
        ball.y += ball.vy;

        // Bounce off walls
        if (ball.x - ball.radius < 0 || ball.x + ball.radius > canvasRef.current!.width) {
          ball.vx *= -1;
        }
        if (ball.y - ball.radius < 0 || ball.y + ball.radius > canvasRef.current!.height) {
          ball.vy *= -1;
        }

        // Draw ball
        ctx.beginPath();
        ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
        ctx.fillStyle = `hsl(${frame % 360}, 70%, 60%)`;
        ctx.fill();
      });

      frame++;
      requestAnimationFrame(animate);
    };

    animate();
  }, []);

  return (
    <div className="relative w-full h-[300px] rounded-lg overflow-hidden bg-black/5">
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      )}
      <canvas
        ref={canvasRef}
        width={800}
        height={300}
        className="w-full h-full"
      />
    </div>
  );
};

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary/20">
      {/* Hero Section */}
      <header className="container mx-auto px-4 py-20 text-center relative overflow-hidden">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h1 className="text-7xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-primary-foreground mb-6">
            Vellum Engine
          </h1>
          <p className="text-2xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            O motor de jogos multiplataforma mais avançado, com suporte a física em tempo real,
            áudio espacial e gráficos de alta performance
          </p>
          <div className="flex gap-4 justify-center">
            <Link href="/auth">
              <Button size="lg" className="gap-2 text-lg px-8">
                Começar Agora
              </Button>
            </Link>
            <Link href="/docs">
              <Button size="lg" variant="outline" className="gap-2 text-lg px-8">
                Documentação
              </Button>
            </Link>
          </div>
        </motion.div>
      </header>

      {/* Demo Section */}
      <section className="container mx-auto px-4 py-16">
        <h2 className="text-4xl font-bold text-center mb-8">
          Veja a Engine em Ação
        </h2>
        <DemoSection />
      </section>

      {/* Features Grid */}
      <section className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <FeatureCard
            title="🎮 Multiplataforma"
            description="Desenvolva uma vez, publique em qualquer lugar: Web, Desktop, iOS e Android com otimização nativa"
            icon={() => <SiUnity className="text-primary" />}
            delay={0.1}
          />

          <FeatureCard
            title="⚡ Física Avançada"
            description="Sistema de física robusto com detecção de colisão precisa, joints e simulação em tempo real"
            icon={() => <SiUnrealengine className="text-primary" />}
            delay={0.2}
          />

          <FeatureCard
            title="🎵 Áudio 3D"
            description="Sistema de áudio espacial com efeitos em tempo real, mixagem dinâmica e suporte a HRTF"
            icon={() => <SiGodotengine className="text-primary" />}
            delay={0.3}
          />

          <FeatureCard
            title="🎨 Editor Visual"
            description="Interface intuitiva para criar cenas, com suporte a drag-and-drop e preview em tempo real"
            delay={0.4}
          />

          <FeatureCard
            title="🚀 Alta Performance"
            description="Otimizado com WebAssembly e WebGL 2.0 para máxima performance em todas as plataformas"
            delay={0.5}
          />

          <FeatureCard
            title="📦 Assets"
            description="Marketplace integrado com assets prontos para uso, incluindo modelos 3D, sprites e efeitos sonoros"
            delay={0.6}
          />
        </div>
      </section>

      {/* Comparison Section */}
      <section className="container mx-auto px-4 py-16">
        <h2 className="text-4xl font-bold text-center mb-12">
          Por que escolher o Vellum Engine?
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          <motion.div
            className="flex flex-col items-center"
            whileHover={{ scale: 1.05 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            <SiUnrealengine className="text-6xl mb-4 text-primary" />
            <h3 className="text-xl font-semibold mb-2">vs. Unreal Engine</h3>
            <p className="text-muted-foreground">
              Mais leve e simples de usar, ideal para jogos web e mobile
            </p>
          </motion.div>

          <motion.div
            className="flex flex-col items-center"
            whileHover={{ scale: 1.05 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            <SiUnity className="text-6xl mb-4 text-primary" />
            <h3 className="text-xl font-semibold mb-2">vs. Unity</h3>
            <p className="text-muted-foreground">
              Sem taxas de licença, desenvolvimento totalmente open source
            </p>
          </motion.div>

          <motion.div
            className="flex flex-col items-center"
            whileHover={{ scale: 1.05 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            <SiGodotengine className="text-6xl mb-4 text-primary" />
            <h3 className="text-xl font-semibold mb-2">vs. Godot</h3>
            <p className="text-muted-foreground">
              Melhor suporte web e ferramentas multiplataforma nativas
            </p>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-16">
        <motion.div
          className="bg-primary/10 rounded-2xl p-12 text-center"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl font-bold mb-4">
            Pronto para Criar Jogos Incríveis?
          </h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Junte-se a milhares de desenvolvedores que já estão criando
            jogos extraordinários com o Vellum Engine
          </p>
          <Link href="/auth">
            <Button size="lg" className="gap-2 text-lg px-12">
              Começar Gratuitamente
            </Button>
          </Link>
        </motion.div>
      </section>

      {/* Seção de Suporte */}
      <section className="container mx-auto px-4 py-16 bg-background/50">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4">Suporte Premium</h2>
          <p className="text-xl text-muted-foreground">
            Estamos aqui para ajudar você a criar jogos incríveis
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          <div className="space-y-6">
            <Card className="p-6">
              <h3 className="text-2xl font-semibold mb-4">Contato Direto</h3>
              <form className="space-y-4">
                <div>
                  <Input placeholder="Seu nome" />
                </div>
                <div>
                  <Input type="email" placeholder="Seu e-mail" />
                </div>
                <div>
                  <Textarea
                    placeholder="Como podemos ajudar?"
                    className="min-h-[100px]"
                  />
                </div>
                <Button className="w-full gap-2">
                  <Send className="w-4 h-4" />
                  Enviar Mensagem
                </Button>
              </form>
            </Card>

            <div className="grid grid-cols-2 gap-4">
              <a href="https://twitter.com/vellumengine" target="_blank" rel="noopener noreferrer">
                <Button variant="outline" className="w-full gap-2">
                  <Twitter className="w-4 h-4" />
                  Twitter
                </Button>
              </a>
              <a href="https://github.com/vellumengine" target="_blank" rel="noopener noreferrer">
                <Button variant="outline" className="w-full gap-2">
                  <Github className="w-4 h-4" />
                  Github
                </Button>
              </a>
            </div>
          </div>

          <div className="space-y-6">
            <Card className="p-6">
              <h3 className="text-2xl font-semibold mb-4">FAQ</h3>
              <div className="space-y-4">
                <details className="group">
                  <summary className="cursor-pointer font-medium hover:text-primary">
                    Como começar com a Vellum Engine?
                  </summary>
                  <p className="mt-2 text-muted-foreground">
                    Comece criando uma conta gratuita e explore nossa documentação detalhada.
                    Temos tutoriais passo a passo para iniciantes.
                  </p>
                </details>

                <details className="group">
                  <summary className="cursor-pointer font-medium hover:text-primary">
                    Quais plataformas são suportadas?
                  </summary>
                  <p className="mt-2 text-muted-foreground">
                    A Vellum Engine suporta Web, Desktop (Windows, macOS, Linux) e
                    Mobile (iOS, Android) com otimizações nativas.
                  </p>
                </details>

                <details className="group">
                  <summary className="cursor-pointer font-medium hover:text-primary">
                    Como funciona o suporte premium?
                  </summary>
                  <p className="mt-2 text-muted-foreground">
                    Oferecemos suporte prioritário 24/7, consultoria técnica e
                    ajuda personalizada para seu projeto.
                  </p>
                </details>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="text-2xl font-semibold mb-4">Recursos</h3>
              <div className="space-y-2">
                <Link href="/docs">
                  <Button variant="ghost" className="w-full justify-start">
                    📚 Documentação Completa
                  </Button>
                </Link>
                <Link href="/tutorials">
                  <Button variant="ghost" className="w-full justify-start">
                    🎓 Tutoriais em Vídeo
                  </Button>
                </Link>
                <Link href="/showcase">
                  <Button variant="ghost" className="w-full justify-start">
                    🎮 Galeria de Jogos
                  </Button>
                </Link>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Chat Flutuante */}
      <Dialog>
        <DialogTrigger asChild>
          <Button
            className="fixed bottom-6 right-6 rounded-full w-14 h-14 shadow-lg"
            size="icon"
          >
            <MessageCircle className="w-6 h-6" />
          </Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Chat de Suporte</DialogTitle>
          </DialogHeader>
          <div className="min-h-[300px] space-y-4">
            <div className="bg-muted p-4 rounded-lg">
              <p className="text-sm">
                Olá! Como posso ajudar você hoje?
              </p>
            </div>
            <div className="flex gap-2">
              <Input placeholder="Digite sua mensagem..." className="flex-1" />
              <Button size="icon">
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Footer */}
      <footer className="container mx-auto px-4 py-8 border-t">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <p className="text-muted-foreground">
            © {new Date().getFullYear()} Vellum Engine. Todos os direitos reservados.
          </p>
          <div className="flex gap-4 mt-4 md:mt-0">
            <Link href="/about">
              <Button variant="ghost">Sobre</Button>
            </Link>
            <Link href="/blog">
              <Button variant="ghost">Blog</Button>
            </Link>
            <Link href="/contact">
              <Button variant="ghost">Contato</Button>
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}