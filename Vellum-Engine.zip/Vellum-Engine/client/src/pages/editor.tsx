import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import Canvas from "@/components/editor/Canvas";
import Inspector from "@/components/editor/Inspector";
import SceneHierarchy from "@/components/editor/SceneHierarchy";
import Toolbar from "@/components/editor/Toolbar";
import { Scene } from "@/lib/engine/scene";
import { GameObject } from "@/lib/engine/gameObject";
import { RectRenderer, PhysicsRenderer } from "@/lib/engine/components";
import { useInput } from "@/lib/engine/input";

export default function Editor() {
  const [scene] = useState(() => {
    const newScene = new Scene();

    // Add a ground
    const ground = new GameObject("Ground", {
      x: 400,
      y: 500,
      rotation: 0,
      scale: { x: 1, y: 1 }
    });
    ground.addComponent(new RectRenderer(800, 20, "#666"));
    ground.addComponent(new PhysicsRenderer({
      x: 400,
      y: 500,
      width: 800,
      height: 20,
      mass: Infinity
    }));
    newScene.addObject(ground);

    // Add some boxes
    for (let i = 0; i < 5; i++) {
      const box = new GameObject(`Box ${i}`, {
        x: 200 + i * 100,
        y: 100 + i * 50,
        rotation: 0,
        scale: { x: 1, y: 1 }
      });
      box.addComponent(new RectRenderer(50, 50, `hsl(${i * 60}, 70%, 50%)`));
      box.addComponent(new PhysicsRenderer({
        x: 200 + i * 100,
        y: 100 + i * 50,
        width: 50,
        height: 50,
        mass: 1
      }));
      newScene.addObject(box);
    }

    return newScene;
  });

  const [selectedObject, setSelectedObject] = useState<GameObject | null>(null);
  const input = useInput();

  // Game loop
  useEffect(() => {
    let animationFrameId: number;

    const gameLoop = (timestamp: number) => {
      scene.update(timestamp);
      animationFrameId = requestAnimationFrame(gameLoop);
    };

    animationFrameId = requestAnimationFrame(gameLoop);

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [scene]);

  return (
    <div className="h-screen flex flex-col bg-background">
      <Toolbar scene={scene} />

      <div className="flex-1 flex">
        <div className="w-64 border-r">
          <SceneHierarchy 
            scene={scene}
            selectedObject={selectedObject}
            onSelectObject={setSelectedObject}
          />
        </div>

        <div className="flex-1">
          <Canvas scene={scene} />
        </div>

        <div className="w-80 border-l">
          <Inspector 
            selectedObject={selectedObject}
            onObjectChange={() => scene.render} 
          />
        </div>
      </div>
    </div>
  );
}