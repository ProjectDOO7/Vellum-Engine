import { Switch, Route, useLocation } from "wouter";
import { QueryClientProvider, useQuery } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { Loader2 } from "lucide-react";
import Landing from "@/pages/Landing";
import Projects from "@/pages/projects";
import Editor from "@/pages/editor";
import Auth from "@/pages/auth";
import Docs from "@/pages/docs";
import NotFound from "@/pages/not-found";

function PrivateRoute(props: { component: React.ComponentType }) {
  const [location, setLocation] = useLocation();
  const { data: user, isLoading, error } = useQuery({
    queryKey: ["/api/auth/me"],
    queryFn: async () => {
      try {
        const res = await fetch("/api/auth/me", { credentials: "include" });
        if (res.status === 401) return null;
        const data = await res.json();
        return data;
      } catch (error) {
        console.error("Auth error:", error);
        return null;
      }
    },
    retry: 1
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
        <span className="ml-2 text-lg text-muted-foreground">Carregando...</span>
      </div>
    );
  }

  if (error) {
    console.error("Auth error:", error);
    setLocation("/auth");
    return null;
  }

  if (!user) {
    setLocation("/auth");
    return null;
  }

  const Component = props.component;
  return <Component />;
}

function Router() {
  const { data: user, isLoading } = useQuery({
    queryKey: ["/api/auth/me"],
    queryFn: async () => {
      try {
        const res = await fetch("/api/auth/me", { credentials: "include" });
        if (res.status === 401) return null;
        return res.json();
      } catch (error) {
        console.error("Router auth error:", error);
        return null;
      }
    },
    retry: 1
  });

  return (
    <Switch>
      {/* Páginas públicas */}
      <Route path="/" component={Landing} />
      <Route path="/docs" component={Docs} />
      <Route path="/docs/:section" component={Docs} />

      {/* Se já estiver logado, redireciona para projects */}
      <Route path="/auth">
        {user ? <Projects /> : <Auth />}
      </Route>

      {/* Rotas protegidas */}
      <Route path="/projects" component={() => <PrivateRoute component={Projects} />} />
      <Route path="/editor/:id" component={() => <PrivateRoute component={Editor} />} />

      {/* Fallback */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router />
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;