import { CapacitorConfig } from '@capacitor/cli';
import { buildConfigs } from './config/build.config';

const config: CapacitorConfig = {
  appId: buildConfigs.mobile.capacitor.appId,
  appName: buildConfigs.mobile.capacitor.appName,
  webDir: 'dist/web',
  server: {
    androidScheme: 'https',
    cleartext: true,
    allowNavigation: ['*']
  },
  android: {
    backgroundColor: '#000000',
    allowMixedContent: true,
    captureInput: true,
    webContentsDebuggingEnabled: true
  },
  ios: {
    backgroundColor: '#000000',
    contentInset: 'automatic',
    allowsLinkPreview: true,
    scrollEnabled: true,
    useWebKit: true
  }
};

export default config;